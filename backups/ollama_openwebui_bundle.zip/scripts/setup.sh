#!/usr/bin/env bash
set -e
# simple setup: create venv and install requirements if present
DIR=${1:-.}
python3 -m venv $DIR/.venv
source $DIR/.venv/bin/activate
pip install --upgrade pip
if [ -f $DIR/requirements.txt ]; then
  pip install -r $DIR/requirements.txt
fi
