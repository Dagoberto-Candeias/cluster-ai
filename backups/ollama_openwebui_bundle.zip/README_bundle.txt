OLLAMA + OPEN WEBUI BUNDLE
Contents organized into folders:

/docs - Markdown guide split in 4 parts and PDFs
/deploy - docker-compose files, nginx configs, README for TLS deploy
/scripts - helper scripts: issue-certs, issue-certs-robust.sh, setup.sh
/extras - other working files (if any)

How to use:
1) Copy the 'deploy' folder to your server (scp or rsync).
2) Ensure Ollama is running on the host (listening on :11434) before starting compose.
3) Follow README_deploy_TLS.md or README_FINAL_DEPLOY.md for detailed steps.
4) Use issue-certs-robust.sh to issue certificates (pass domain and email).

Enjoy!
